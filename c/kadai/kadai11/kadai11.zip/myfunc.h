/*
    kadai11.c

    プロトタイプ宣言をするプログラム
    作成者:宮﨑 九十九
    作成日:2025/07/09
*/

// インクルードガード
#pragma once

// プロトタイプ宣言
int min(int a, int b);
int max(int a, int b);
void min_max(int n);